/**
 * 
 */
package gestionReseaux;

/**
 * @author Simon
 *
 */
public class Local extends Objet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * @param arguments
	 * 
	 * */
	private String description;
	private String lieu;
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the lieu
	 */
	public String getLieu() {
		return lieu;
	}
	/**
	 * @param lieu the lieu to set
	 */
	public void setLieu(String lieu) {
		this.lieu = lieu;
	}
	
	//Surcharge des méthodes de la classe Objet
	public void ajouterObjet() {
		System.out.println("Ajout d'un nouveau lieu. \n");
		//saisie du nom
		super.ajouterObjet();
		//saisie description
		//saisie lieu
	}
	
	public void modifierObjet(Objet o) {
		char reponse = 'n';
		
		System.out.println("Modification d'un lieu. \n");
		do {
			System.out.print("Voulez vous modifier le nom du lieu ? (o/n) ");
			//saisie de reponse
		} while (reponse !='o' || reponse !='n');
		if (reponse == 'o') {
			//modification du nom du lieu
			super.modifierObjet(o);
			} else {
			//modification des paramètres spécifiques
			}
	}
	
	//Nouvelles méthodes spécifiques à Local
	
}
