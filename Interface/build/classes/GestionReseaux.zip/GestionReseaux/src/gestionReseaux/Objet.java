/**
 * 
 */
package gestionReseaux;

import java.io.*;

/**
 * @author Simon
 *
 */
public class Objet implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * @param arguments
	 * 
	 * */
	private int identifiantObjet = (int) serialVersionUID;
	private String nom;
	/**
	 * @return the identifiantObjet
	 */
	public int getIdentifiantObjet() {
		return identifiantObjet;
	}
	/**
	 * @param identifiantObjet the identifiantObjet to set
	 */
	public void setIdentifiantObjet(int identifiantObjet) {
		this.identifiantObjet = identifiantObjet;
	}
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void ajouterObjet() {
		//Creer un nouvel objet
	}
	
	public void supprimerObjet(Objet o) {
		//Supprimer un objet de la base de données
	}
	
	public void modifierObjet(Objet o) {
		//Selectionner le paramètre à modifier
		//Modifier le paramètre dans la base de données
	}
}
