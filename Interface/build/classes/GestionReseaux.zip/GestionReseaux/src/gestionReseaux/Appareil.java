/**
 * 
 */
package gestionReseaux;

/**
 * @author Simon
 *
 */
public class Appareil extends Objet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//Surcharge des méthodes de la classe Objet
	public void ajouterObjet() {
		System.out.println("Ajout d'un nouvel appareil. \n");
		super.ajouterObjet();
	}
	
	public void modifierObjet(Objet o) {
		System.out.println("Modification d'un appareil. \n");
		super.modifierObjet(o);
	}

}
