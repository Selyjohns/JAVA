/**
 * 
 */
package gestionReseaux;

/**
 * @author Simon
 *
 */
public class Interface {

}
