/**
 * 
 */
package gestionReseaux;

/**
 * @author Simon
 *
 */
public class Salle extends Objet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * @param arguments
	 * 
	 * */
	String description;

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	//Surcharge des méthodes de la classe Objet
	public void ajouterObjet() {
		System.out.println ("Ajout d'une nouvelle salle. \n");
		//saisie du nom
		super.ajouterObjet();
		//saisie de la description
	}
	
	public void modifierObjet(Objet o) {
		char reponse = 'n';
		
		System.out.println("Modification d'une salle. \n");
		do {
			System.out.print("Voulez vous modifier le nom de la salle ? (o/n) ");
			//saisie de reponse
		} while (reponse !='o' || reponse !='n');
		if (reponse == 'o') {
			//modification du nom de la salle
			super.modifierObjet(o);
			} else {
			//modification des paramètres spécifiques
			}
	}

}
