/**
 * 
 */
package gestionReseaux;

/**
 * @author Simon
 *
 */
public class OS extends Objet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * @param arguments
	 * 
	 * */
	String version;

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	
	//Surcharge des méthodes de la classe Objet
	public void ajouterObjet() {
		System.out.println("Ajout d'un nouvel OS. \n");
		//saisie du nom
		super.ajouterObjet();
		//saisie version
	}
	
	public void modifierObjet(Objet o) {
		char reponse = 'n';
		
		System.out.println("Modification d'un OS. \n");
		do {
			System.out.print("Voulez vous modifier le nom de l'OS ? (o/n) ");
			//saisie de reponse
		} while (reponse !='o' || reponse !='n');
		if (reponse == 'o') {
			//modification du nom de l'OS
			super.modifierObjet(o);
			} else {
			//modification des paramètres spécifiques
			}
	}
}
